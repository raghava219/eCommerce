
-- MYSQL------------------

CREATE DATABASE IF NOT EXISTS myusers;
USE myusers;

DROP TABLE IF EXISTS `myusers`.`users`;
CREATE TABLE `myusers`.`users` (
  `users_id` INT NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(45) NOT NULL,
  `password` VARCHAR(45) NULL,
  `firstname` VARCHAR(45) NOT NULL,
  `lastname` VARCHAR(45) NULL,
  `email` VARCHAR(45) NULL,
  `address` VARCHAR(45) NULL,
  `phone` INT NULL,
  PRIMARY KEY (`users_id`));


  DROP TABLE IF EXISTS `myusers`.`person`;
CREATE TABLE `myusers`.`person` (
  `person_id` INT NOT NULL,
  `name` VARCHAR(45) NULL,
  `country` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`person_id`));

  DROP TABLE IF EXISTS `myusers`.`book`;
CREATE TABLE `myusers`.`book` (
  `person_id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NULL,
  `country` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`person_id`));

CREATE SEQUENCE person_seq
  MINVALUE 1
  MAXVALUE 999999
  START WITH 1000
  INCREMENT BY 1
  CACHE 20;


-----------Oracle

CREATE TABLE users (
  users_id INT GENERATED ALWAYS as IDENTITY(START with 1 INCREMENT by 1),
  username VARCHAR(45) NOT NULL,
  password VARCHAR(45) NULL,
  firstname VARCHAR(45) NOT NULL,
  lastname VARCHAR(45) NULL,
  email VARCHAR(45) NULL,
  address VARCHAR(45) NULL,
  phone INT NULL,
  PRIMARY KEY (users_id));


 drop table person;
  CREATE TABLE person (
  person_id INT,
  name VARCHAR(45) NULL,
  country VARCHAR(45) NOT NULL,
  PRIMARY KEY (person_id));

  CREATE TABLE book (
  person_id INT GENERATED ALWAYS as IDENTITY(START with 1 INCREMENT by 1),
  name VARCHAR(45) NULL,
  country VARCHAR(45) NOT NULL,
  PRIMARY KEY (person_id));


CREATE SEQUENCE person_seq
  MINVALUE 1
  MAXVALUE 999999
  START WITH 1000
  INCREMENT BY 1
  CACHE 20;
