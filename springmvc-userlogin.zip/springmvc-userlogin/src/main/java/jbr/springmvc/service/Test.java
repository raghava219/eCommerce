package jbr.springmvc.service;

/**
 * Created with IntelliJ IDEA.
 * User: q840039
 * Date: 2/11/18
 * Time: 5:56 AM
 * To change this template use File | Settings | File Templates.
 */
public class Test {
    public static void main(String[] args){
          for(int i=0; i<10; i++){
              if(!(i ==5)){
                  continue;
              }
          System.out.println(" value "+i);
          }
    }
}
