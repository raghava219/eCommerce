package jbr.springmvc.dao;

import jbr.springmvc.model.Book;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: q840039
 * Date: 2/10/18
 * Time: 3:49 PM
 * To change this template use File | Settings | File Templates.
 */
public interface BooksDAO {

    public void addBook(Book book);
    public void updateBook(Book book);
    public List<Book> listBooks();
    public Book getBookById(int book_id);
    public void removeBook(int book_id);

}
