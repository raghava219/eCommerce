package jbr.springmvc.dao;

import jbr.springmvc.model.Book;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: q840039
 * Date: 2/10/18
 * Time: 4:43 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class BooksDAOImpl implements BooksDAO{

    private static final Logger log = LoggerFactory.getLogger(BooksDAOImpl.class);

    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sf){
        this.sessionFactory = sf;
    }

    @Override
    public void addBook(Book book) {
        Session session = this.sessionFactory.getCurrentSession();
        session.persist(book);
        log.info("Book is persisted to DB, book details: "+book);
    }

    @Override
    public void updateBook(Book book) {
        Session session;
    }

    @Override
    public List<Book> listBooks() {
        return null;
    }

    @Override
    public Book getBookById(int book_id) {
        return null;
    }

    @Override
    public void removeBook(int book_id) {

    }
}
