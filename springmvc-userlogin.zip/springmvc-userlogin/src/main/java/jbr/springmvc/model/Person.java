package jbr.springmvc.model;

import javax.persistence.*;

/**
 * Entity bean with JPA annotations
 * Hibernate provides JPA implementation
 * @author pankaj
 *
 */
@Entity
@Table(name="PERSON")
public class Person {

	@Id
	@Column(name="person_id")
    //@GeneratedValue(strategy=GenerationType.IDENTITY)
    //https://www.thoughts-on-java.org/hibernate-tips-use-custom-sequence/
    @GeneratedValue(generator = "person_sequence", strategy=GenerationType.SEQUENCE)
    @SequenceGenerator(name="person_sequence", sequenceName = "person_seq")
	private int personId;

    @Column(name="name")
    private String name;

    @Column(name="country")
	private String country;

    public int getPersonId() {
        return personId;
    }

    public void setPersonId(int personId) {
        this.personId = personId;
    }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}
	
	@Override
	public String toString(){
		return "id="+personId+", name="+name+", country="+country;
	}
}
