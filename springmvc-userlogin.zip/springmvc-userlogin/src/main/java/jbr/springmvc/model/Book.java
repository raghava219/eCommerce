package jbr.springmvc.model;

import javax.persistence.*;

/**
 * Created with IntelliJ IDEA.
 * User: q840039
 * Date: 2/10/18
 * Time: 3:50 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name="BOOK")
public class Book {

    @Id
    @Column(name="book_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int bookId;

    private String bookName;

    private String authorName;

    private float price;

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }
}
