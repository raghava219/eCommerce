package com.raghava.service;

import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.web.context.WebApplicationContext;

import com.raghava.controller.UserController;

public class ApplicationContextProvider implements InitializingBean, ApplicationContextAware{

	private static final Logger logger = Logger.getLogger(UserController.class);
	private ApplicationContext applicationContext;
	
	@Override
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		logger.info("Initializing e-Commerce configurations");
		
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
		// TODO Auto-generated method stub
		if(applicationContext instanceof WebApplicationContext){
            this.applicationContext = (WebApplicationContext) applicationContext;
        }
        if(applicationContext instanceof FileSystemXmlApplicationContext){
            this.applicationContext = (FileSystemXmlApplicationContext) applicationContext;
        }
		
	}
	
	public ApplicationContext getApplicationContext() {
        return applicationContext;
    }

}
