package com.raghava.dao;

import org.springframework.jdbc.core.JdbcTemplate; 
import com.raghava.controller.User;



public class UserSpringDAOImpl implements UserDAO{
	
private JdbcTemplate jdbcTemplate;  
  
public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {  
    this.jdbcTemplate = jdbcTemplate;  
}  
  
public int saveUser(User e){  
    String query="insert into user(name,password) values('"+e.getUserName()+"','"+e.getPassWord()+"')";  
    return jdbcTemplate.update(query);  
}  
public int updateUser(User e){  
    String query="update user set name='"+e.getUserName()+"',salary='"+e.getPassWord()+"' where id='"+e.getId()+"' ";  
    return jdbcTemplate.update(query);  
}  
public int deleteUser(User e){  
    String query="delete from user where id='"+e.getId()+"' ";  
    return jdbcTemplate.update(query);  
}  
  
} 
//https://www.javatpoint.com/spring-JdbcTemplate-tutorial

/*
CREATE TABLE IF NOT EXISTS `user` (
		  `USER_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		  `NAME` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
		  `PASSWORD` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
		PRIMARY KEY (`USER_ID`)
		)
*/