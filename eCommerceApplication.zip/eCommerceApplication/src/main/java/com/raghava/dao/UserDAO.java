package com.raghava.dao;

import org.springframework.jdbc.core.JdbcTemplate; 
import com.raghava.controller.User;



public interface UserDAO {
	
  
public void setJdbcTemplate(JdbcTemplate jdbcTemplate);
  
public int saveUser(User e);

public int updateUser(User e);

public int deleteUser(User e);
  
} 
//https://www.javatpoint.com/spring-JdbcTemplate-tutorial

/*
CREATE TABLE IF NOT EXISTS `user` (
		  `USER_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		  `NAME` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
		  `PASSWORD` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
		PRIMARY KEY (`USER_ID`)
		)
*/