package com.raghava.controller;

import java.io.StringWriter;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import org.apache.log4j.Logger;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.raghava.controller.User;


@Controller
public class UserController {

	private static final Logger logger = Logger.getLogger(UserController.class);
	
	@RequestMapping(value="/",method=RequestMethod.GET)
	public String home(Locale local,Model model){
		logger.info("Welcome user to eCommerce App "+local);
		return "login";
	}
	
	@RequestMapping(value="/login", method=RequestMethod.GET)
	public String loginPage(Locale local, Model model){
		logger.info("Welcome user to eCommerce Login Page "+local);
		return "login";
	}
	
	
	@RequestMapping(value = "/home", method = RequestMethod.POST)
	public String login(@Validated User user, Model model,Locale local) { 
		// What is the purpose of Validated Annotation
		logger.info("Welcome user to eCommerce Home Page "+local);
		Date newDate = new Date();
		DateFormat df = DateFormat.getDateTimeInstance(DateFormat.DATE_FIELD, DateFormat.LONG, local);
		String formatterDate = df.format(newDate);
		model.addAttribute("serverTime", formatterDate); //where are we using this ?
		model.addAttribute("userName", user.getUserName());
		
		
		
		return "home";
	}
	
	
	
	
}
